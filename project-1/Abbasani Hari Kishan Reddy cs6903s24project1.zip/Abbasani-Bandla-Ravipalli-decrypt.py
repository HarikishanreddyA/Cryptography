from collections import Counter
''' for extra credit 
plaintext_dictionary = [
    #1 unconquerable tropical pythagoras rebukingly price ephedra barmiest hastes spades fevers cause wisped overdecorates linked smitten trickle scanning cognize oaken casework significate influenceable precontrived clockers defalcation fruitless splintery kids placidness regenerate harebrained liberalism neuronic clavierist attendees matinees prospectively bubbies longitudinal raving relaxants rigged oxygens chronologist briniest tweezes profaning abeyances fixity gulls coquetted budgerigar drooled unassertive shelter subsoiling surmounted frostlike jobbed hobnailed fulfilling jaywalking testabilit
    Candidate Plaintext #2
protectorates committeemen refractory narcissus bridlers weathercocks occluding orchectomy syncoms denunciation chronaxy imperilment incurred defrosted beamy opticopupillary acculturation scouting curiousest tosh preconscious weekday reich saddler politicize mercerizes saucepan bifold chit reviewable easiness brazed essentially idler dependable predicable locales rededicated cowbird kvetched confusingly airdrops dreggier privileges tempter anaerobes glistened sartorial distrustfulness papillary ughs proctoring duplexed pitas traitorously unlighted cryptographer odysseys metamer either meliorat
    Candidate Plaintext #3
incomes shoes porcine pursue blabbered irritable ballets grabbed scything oscillogram despots pharynxes recompensive disarraying ghoulish mariachi wickerwork orientation candidnesses nets opalescing friending wining cypher headstrong insubmissive oceanid bowlegs voider recook parochial trop gravidly vomiting hurray friended uncontestable situate fen cyclecars gads macrocosms dhyana overruns impolite europe cynical jennet tumor noddy canted clarion opiner incurring knobbed planeload megohm dejecting campily dedicational invaluable praecoces coalescence dibbuk bustles flay acuities centimeters l
    Candidate Plaintext #4
rejoicing nectar asker dreadfuls kidnappers interstate incrusting quintessential neglecter brewage phosphatic angle obliquely bean walkup outflowed squib tightwads trenched pipe extents streakier frowning phantasmagories supinates imbibers inactivates tingly deserter steerages beggared pulsator laity salvageable bestrode interning stodgily cracker excisions quanted arranges poultries sleds shortly packages apparat fledge alderwomen halvah verdi ineffectualness entrenches franchising merchantability trisaccharide limekiln sportsmanship lassitudes recidivistic locating iou wardress estrus potboi

Candidate Plaintext #5

headmaster attractant subjugator peddlery vigil dogfights pixyish comforts aretes felinities copycat salerooms schmeering institutor hairlocks speeder composers dramatics eyeholes progressives reminiscent hermaphrodism simultaneous spondaics hayfork armory refashioning battering darning tapper pancaked unaffected televiewer mussiness pollbook sieved reclines restamp cohosh excludes homelier coacts refashioned loiterer prospectively encouragers biggest pasters modernity governorships crusted buttoned wallpapered enamors supervisal nervily groaning disembody communion embosoming tattles pancakes
    
    
    
    
additional plaintexts:
    #1 surrenderee document spunkiest coquetted abatis leasehold nuclei fogginess genoa traitors blockbuster superpositions flams surprized honcho cetera to transmit psychol wintered gruntingly cheapness translation laborer lissomeness caravansaries reflexes overextends bitter uplift strate filler cupolaed automatic machree nonparasitic unashamed braggy typier potencies greyness gulped masonwork blandisher disks fadeaway origamis manurer olives engine looted whitehall imperils shadowbox jabbing exports
    #2 tumble cooked twirled absinths ceca cheatery raters redeploy niacinamide offeree preventively tangibleness beamy oligarchical microbus intends galvanize indelible tubings overcools rollover maladroit logways frilling skinks affirmatively flatfoots oversleeps consignors completes espadrille booms repaved ofays keens dinosaurs rerouted consignments victimless psychophysical chuckle admissibility muleteer deescalating ovary bowwow assisi fore tubbiest vocatively filially preestablish lacquerers spr
    #3 harmonizations pratique defoliated brashly elegancy henpeck ecumenicism valuta lingers acrobatic mismarriage fruitlessness pattering enables travois nymphs fratricides awakener ordure tribulation elicit nonviable guiles raucously euclidean evangelist preoperative pathogeny frames medium inviabilities retrains crankcase awkwarder stopwatch subclinical irrigators lettuce skidooed fonder teem funguses purviews longshot affaires wearing judo resettle antedate inoperable pinworm pumper annul anteposi
    #4 hark reascended recedes inebriate flowery awkwarder waterbed complacency sikh compartmented dependably alliterations headache basketfuls malocclusions cubistic hint headdresses unfrocks keloidal translucent fidelities instructional graphed baker superb spectroscopies bismark uncanniest detachability letdown querulously unstack curdling chained pointy drippers larch spermicide inextricability anteed improvising jape imponderably lithographic winglets advents triplicating growling fescue salabilit
    #5 enrollee pins datively armiger bisect installs taffeta compliances governorship laceworks preciousness bedizens immaculately disinfect nucleonics biremes mailbags behaves enhance floppiest brutisms registered silenced tuques oryxes coddler undersigned mackintosh misemployment peacemakers pleadings dandification platypuses swig doer reshowed quadrangles locutory encapsules bawdies woolpack valuated malodorously shill cryogenies known distr bonsai morale mirage skit aquacades pi overcommon flippan,
]
'''
def load_dictionary(filename):
    with open(filename, 'r') as file:
        return set(word.strip().lower() for word in file.readlines())

def decrypt_ciphertext(ciphertext, dictionary):
    message_space = "abcdefghijklmnopqrstuvwxyz "
    char_values = {char: i + 1 for i, char in enumerate(message_space)}

    frequencies = Counter(ciphertext.lower())  # Convert ciphertext to lowercase for case-insensitive comparison
    sorted_frequencies = sorted(frequencies.items(), key=lambda x: x[1], reverse=True)

    most_frequent_char = sorted_frequencies[0][0]
    shift_e = char_values[most_frequent_char] - char_values['e']
    shift_space = char_values[most_frequent_char] - char_values[' ']
    shift_a = char_values[most_frequent_char] - char_values['a']
    shift_r = char_values[most_frequent_char] - char_values['r']
    shift_i = char_values[most_frequent_char] - char_values['i']
    shift_o = char_values[most_frequent_char] - char_values['o']
    shift_t = char_values[most_frequent_char] - char_values['t']
    shift_n = char_values[most_frequent_char] - char_values['n']
    shift_s = char_values[most_frequent_char] - char_values['s']
    shift_l = char_values[most_frequent_char] - char_values['l']
    shift_c = char_values[most_frequent_char] - char_values['c']
    shift_u = char_values[most_frequent_char] - char_values['u']

    decrypted_text_e = ""
    decrypted_text_space = ""
    decrypted_text_a = ""
    decrypted_text_r = ""
    decrypted_text_i = ""
    decrypted_text_o = ""
    decrypted_text_t = ""
    decrypted_text_n = ""
    decrypted_text_s = ""
    decrypted_text_l = ""
    decrypted_text_c = ""
    decrypted_text_u = ""

    for char in ciphertext:
        if char.lower() in message_space:  # Check lowercase character against message space
            new_value_e = char_values[char.lower()] - shift_e
            new_value_e = (new_value_e - 1) % len(message_space)
            decrypted_text_e += message_space[new_value_e]

            new_value_space = char_values[char.lower()] - shift_space
            new_value_space = (new_value_space - 1) % len(message_space)
            decrypted_text_space += message_space[new_value_space]

            new_value_a = char_values[char.lower()] - shift_a
            new_value_a = (new_value_a - 1) % len(message_space)
            decrypted_text_a += message_space[new_value_a]

            new_value_r = char_values[char.lower()] - shift_r
            new_value_r = (new_value_r - 1) % len(message_space)
            decrypted_text_r += message_space[new_value_r]

            new_value_i = char_values[char.lower()] - shift_i
            new_value_i = (new_value_i - 1) % len(message_space)
            decrypted_text_i += message_space[new_value_i]

            new_value_o = char_values[char.lower()] - shift_o
            new_value_o = (new_value_o - 1) % len(message_space)
            decrypted_text_o += message_space[new_value_o]

            new_value_t = char_values[char.lower()] - shift_t
            new_value_t = (new_value_t - 1) % len(message_space)
            decrypted_text_t += message_space[new_value_t]

            new_value_n = char_values[char.lower()] - shift_n
            new_value_n = (new_value_n - 1) % len(message_space)
            decrypted_text_n += message_space[new_value_n]

            new_value_s = char_values[char.lower()] - shift_s
            new_value_s = (new_value_s - 1) % len(message_space)
            decrypted_text_s += message_space[new_value_s]

            new_value_l = char_values[char.lower()] - shift_l
            new_value_l = (new_value_l - 1) % len(message_space)
            decrypted_text_l += message_space[new_value_l]

            new_value_c = char_values[char.lower()] - shift_c
            new_value_c = (new_value_c - 1) % len(message_space)
            decrypted_text_c += message_space[new_value_c]

            new_value_u = char_values[char.lower()] - shift_u
            new_value_u = (new_value_u - 1) % len(message_space)
            decrypted_text_u += message_space[new_value_u]
        else:
            decrypted_text_e += char
            decrypted_text_space += char
            decrypted_text_a += char
            decrypted_text_r += char
            decrypted_text_i += char
            decrypted_text_o += char
            decrypted_text_t += char
            decrypted_text_n += char
            decrypted_text_s += char
            decrypted_text_l += char
            decrypted_text_c += char
            decrypted_text_u += char

    decrypted_words_e = decrypted_text_e.split()[:10]  # Limiting to the first three words
    decrypted_words_space = decrypted_text_space.split()[:10]
    decrypted_words_a = decrypted_text_a.split()[:10]
    decrypted_words_r = decrypted_text_r.split()[:10]
    decrypted_words_i = decrypted_text_i.split()[:10]
    decrypted_words_o = decrypted_text_o.split()[:10]
    decrypted_words_t = decrypted_text_t.split()[:10]
    decrypted_words_n = decrypted_text_n.split()[:10]
    decrypted_words_s = decrypted_text_s.split()[:10]
    decrypted_words_l = decrypted_text_l.split()[:10]
    decrypted_words_c = decrypted_text_c.split()[:10]
    decrypted_words_u = decrypted_text_u.split()[:10]

    for word in (decrypted_words_e + decrypted_words_space + decrypted_words_a +
                 decrypted_words_r + decrypted_words_i + decrypted_words_o +
                 decrypted_words_t + decrypted_words_n + decrypted_words_s +
                 decrypted_words_l + decrypted_words_c + decrypted_words_u):
        if word.lower() in dictionary:
            if word in decrypted_words_e:
                return decrypted_text_e
            elif word in decrypted_words_space:
                return decrypted_text_space
            elif word in decrypted_words_a:
                return decrypted_text_a
            elif word in decrypted_words_r:
                return decrypted_text_r
            elif word in decrypted_words_i:
                return decrypted_text_i
            elif word in decrypted_words_o:
                return decrypted_text_o
            elif word in decrypted_words_t:
                return decrypted_text_t
            elif word in decrypted_words_n:
                return decrypted_text_n
            elif word in decrypted_words_s:
                return decrypted_text_s
            elif word in decrypted_words_l:
                return decrypted_text_l
            elif word in decrypted_words_c:
                return decrypted_text_c
            elif word in decrypted_words_u:
                return decrypted_text_u

    return decrypted_text_e  # Default to returning the first outp

def main():
    dictionary_file = 'dictionary.txt'
    dictionary = load_dictionary(dictionary_file)

    ciphertext = input("Enter the ciphertext: ")
    decrypted_output = decrypt_ciphertext(ciphertext, dictionary)
    print("My plaintext guess is:", decrypted_output)

if __name__ == "__main__":
    main()